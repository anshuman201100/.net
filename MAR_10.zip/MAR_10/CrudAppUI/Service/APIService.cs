﻿using System;
using System.Text;
using Microsoft.Net.Http;
using Microsoft.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CrudAppUI.Service
{

    public class APIService
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;

        public APIService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _baseUrl = configuration["ApiBaseUrl"];
        }

        // Handle GET requests
        private void HandleError(Exception ex)
        {
            throw new NotImplementedException();
        }

        public async Task<T> GetAsync<T>(string endpoint)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}/{endpoint}");
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadFromJsonAsync<T>();
            }
            catch (Exception ex)
            {
                HandleError(ex);
                throw;
            }
        }
        //$"{_baseUrl}/{endpoint}"
         //"https: //localhost:7287/api"
        public async Task<T> PostAsync<T>(string endpoint, object data)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("https://localhost:7287/api/", data);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadFromJsonAsync<T>();
            }
            catch (Exception ex)
            {
                HandleError(ex);
                throw;
            }


            //public async Task<T> GetAsync<T>(string url)
            //{
            //    var response = await _httpClient.GetAsync(url);
            //    if (response.IsSuccessStatusCode)
            //    {
            //        var content = await response.Content.ReadAsStringAsync();
            //        return JsonConvert.DeserializeObject<T>(content);
            //    }

            //    // Handle error (you can throw exceptions, return null, or return a default 
            //    throw new HttpRequestException($"Request to {url} failed with status code {response.StatusCode}");
            //}


            // Handle POST requests
            //public  string PostAsync(string url, object body)
            //{
            //    string data= "";
            //    try
            //    {
            //        var json = JsonConvert.SerializeObject(body);
            //        var content = new StringContent(json, Encoding.UTF8, "application/json");

            //        var response =  _httpClient.PostAsync(url, content).Result;

            //        if (response.IsSuccessStatusCode)
            //        {
            //            data =  response.Content.ReadAsStringAsync().Result;
            //        }
            //    }
            //    catch (Exception)
            //    {

            //        throw;
            //    }

            //    return data;

            //}

            // Handle PUT requests
            //public async Task<T> PutAsync<T>(string url, object body)
            //{
            //    var json = JsonConvert.SerializeObject(body);
            //    var content = new StringContent(json, Encoding.UTF8, "application/json");

            //    var response = await _httpClient.PutAsync(url, content);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        var responseContent = await response.Content.ReadAsStringAsync();
            //        return JsonConvert.DeserializeObject<T>(responseContent);
            //    }

            //    // Handle error (you can throw exceptions, return null, or return a default value)
            //    throw new HttpRequestException($"PUT request to {url} failed with status code {response.StatusCode}");
            //}

            //// Handle DELETE requests
            //public async Task<T> DeleteAsync<T>(string url)
            //{
            //    var response = await _httpClient.DeleteAsync(url);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        var responseContent = await response.Content.ReadAsStringAsync();
            //        return JsonConvert.DeserializeObject<T>(responseContent);
            //    }

            //    // Handle error (you can throw exceptions, return null, or return a default value)
            //    throw new HttpRequestException($"DELETE request to {url} failed with status code {response.StatusCode}");
            //}
        }


    }
}

