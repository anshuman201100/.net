using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CrudAppUI.Views.UserUI
{
    public class AddUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
