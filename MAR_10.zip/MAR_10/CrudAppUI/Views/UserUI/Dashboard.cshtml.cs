using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CrudAppUI.Views.UserUI
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
