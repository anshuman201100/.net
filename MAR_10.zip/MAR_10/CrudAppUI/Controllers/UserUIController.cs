﻿using Microsoft.AspNetCore.Mvc;
using CrudAppUI.Service;
using CrudAppUI.Models;

using System.Threading.Tasks;



namespace CrudAppUI.Controllers
{
    
    public class UserUIController : Controller
    {
        private readonly APIService _apiService;

        public UserUIController(APIService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public IActionResult AddUserForm()
        {
            UserModel User = new UserModel();
            return View(User);
        }

        [HttpPost]

        public async Task<IActionResult> AddUser( UserModel User)
        {
            try
            {
                var result =  _apiService.PostAsync<UserModel>("User", User);

                    if (result != null)
                    {
                        return RedirectToAction("AddUserForm");
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "An Error Occured While Adding the user.";
                    }
            }
            catch (Exception)
            {

                throw;
            }
            return View("AddUserForm", User);
        }

        //[HttpGet]
        //public IActionResult LoginUserForm()
        //{
        //    LoginModel Data = new LoginModel();
        //    Data.Email = "A@a.com";
        //    Data.UserPassword = "password";
        //    return View(Data);
        //}
        [HttpPost ("LoginUser")]
        public async Task<IActionResult> LoginUser( LoginModel LoginCredentials)
        {
            try
            {
                LoginModel result = new LoginModel();
                result = await _apiService.PostAsync<LoginModel>("User/LoginUser", LoginCredentials);

                if (result != null)
                {
                    return RedirectToAction("DashBoard", result);
                }
                else
                {
                    ViewBag.ErrorMessage = "An Error Occured While Adding the user.";
                }
            }
            catch (Exception)
            {

                throw;
            }
            return View("AddUserForm", User);
        }

        public IActionResult DashBoard(UserModel User)
        {
            return View(User);
        }


    }
}
