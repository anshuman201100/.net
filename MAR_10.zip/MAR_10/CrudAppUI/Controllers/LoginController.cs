﻿using Microsoft.AspNetCore.Mvc;
using CrudAppUI.Models;

namespace CrudAppUI.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public IActionResult LoginUserForm()
        {
            LoginModel Data = new LoginModel();
       
            return View(Data);
        }
    }
}
