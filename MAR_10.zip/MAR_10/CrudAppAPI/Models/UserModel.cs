﻿namespace CrudAppAPI.Models
{
    public class UserModel
    {
        public string UserName { get; set; }  
        public string Email { get; set; }  
        public string UserPassword { get; set; }
        public string Contact { get; set; }  
        public string Branch { get; set; }  
        public string UserRole { get; set; }
    }
}
