﻿namespace CrudAppAPI.Models
{
    public class LoginModel
    {
        public string Email { get; set; }
        public string UserPassword { get; set; }
    }
}
