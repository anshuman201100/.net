﻿using Microsoft.AspNetCore.Mvc;
using CrudAppAPI.Models;
using CrudAppAPI.Repository;
using Microsoft.IdentityModel.Tokens;
using System.Diagnostics.Eventing.Reader;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CrudAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private readonly UserRepository _userRepository;

        public UserController(IConfiguration configuration)
        {
            _userRepository = new UserRepository(configuration);
        }

        

        [HttpPost]
        public IActionResult AddUser([FromBody] UserModel User)
        {
            if (User == null)
                return BadRequest("Invalid Data");

            _userRepository.AddUser(User);
            return Ok("User Data Added Successfully");
        }


        [HttpPost("LoginUser")]

        public IActionResult LoginUser([FromBody] LoginModel LoginCredentials)
        {

            UserModel userModel = new UserModel();
            string Message = "";

            try
            {


                if (!string.IsNullOrEmpty(LoginCredentials.Email) && !string.IsNullOrEmpty(LoginCredentials.UserPassword))
                {
                    userModel = _userRepository.AuthenticateUser(LoginCredentials.Email, LoginCredentials.UserPassword);
                    if (userModel != null && !string.IsNullOrEmpty(userModel.UserName))
                    {
                        
                        Message = "Login successful.";
                    }
                    else
                        Message = "Login failed.";
                }
                else
                {
                    Message = "Userid or password required";
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;

            }
            return Ok(new
            {
                Message = Message,
                Data = userModel
            });
        }
    }
}
