﻿using CrudAppAPI.Models;
using Microsoft.AspNetCore.Mvc.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CrudAppAPI.Repository
{
    public class UserRepository
    {
        private readonly string _connectionString;

        public UserRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public bool AddUser(UserModel user)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                using (var command = new SqlCommand("spAddUser", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserName", user.UserName);
                    command.Parameters.AddWithValue("@Email", user.Email);
                    command.Parameters.AddWithValue("@UserPassword", user.UserPassword);
                    command.Parameters.AddWithValue("@Contact", user.Contact);
                    command.Parameters.AddWithValue("@Branch", user.Branch);
                    command.Parameters.AddWithValue("@UserRole", user.UserRole);
                   

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
        public UserModel AuthenticateUser(string Email, string Password)
        {

            UserModel userModel = new UserModel();
            using (var connection = new SqlConnection(_connectionString))
            {
                using(var command = new SqlCommand("spUserLogin",connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Email", Email);
                    command.Parameters.AddWithValue("@Password", Password);

                    connection.Open();
                    using(SqlDataReader reader = command.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            reader.Read();
                             userModel = new UserModel
                            {
                                UserName = reader["UserName"].ToString(),
                                Email = reader["Email"].ToString(),
                                Contact = reader["Contact"].ToString(),
                                Branch = reader["Branch"].ToString(),
                                UserRole = reader["UserRole"].ToString()
                            };
                        }


                    }
                    return userModel;


                }
            }

        }
    }
}

